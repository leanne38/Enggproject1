/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int x, i;
   char message[100];//timiting string to 100 characters
   
   printf("Enter encrypted message here:");
   scanf("%s", &message);
   printf("enter decryption key here:");
   scanf("%d", &x);
   
   for (i = 0; message[i] != '\0'; i++);//initialising counter to 0 and loop run conditions
   
       if(message[i] >= 'a'&& message[i] <= 'z')
       {
           message[i] = message[i] - x;
       }
       else if (message[i] >= 'A' && message[i] <= 'z')
       {
           message[i] = message[i] - x;
          
           if (message[i] > 'Z')
           message[i] = message[i] +'z' - 'a' + 1;
       }
   
   printf("your decrypted message is: %s", message);
   
}
